package com.bank.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;












import com.bank.entity.AccountMaster;
import com.bank.entity.Admin;
import com.bank.entity.Customer;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;

@Repository
public class BankRepositoryImpl implements IBankRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public UserTable check(UserTable user) {
		String q="SELECT b FROM UserTable b WHERE b.userId=:puid AND b.loginPassword=:ppass";
		TypedQuery<UserTable> query=entityManager.createQuery(q,UserTable.class);
		query.setParameter("puid", user.getUserId());
		System.err.println(user.getUserId());
		query.setParameter("ppass",user.getLoginPassword());
		return query.getSingleResult(); 
		
		
	}
@Override
	public AccountMaster getAccountBalance(long accId) {
		String q="SELECT g FROM AccountMaster g WHERE g.accountId=:paccblnce";
		TypedQuery<AccountMaster> query2=entityManager.createQuery(q,AccountMaster.class);
		query2.setParameter("paccblnce",accId);
		return  query2.getSingleResult();
	}
@Override
public int getChangeAddress(long accId, String cadd) {
	String q = "UPDATE Customer c SET c.customerAddress=:padd WHERE c.accountId=:pId";
	
	Query query=entityManager.createQuery(q);
	query.setParameter("pId", accId);
	query.setParameter("padd",cadd);
	return  query.executeUpdate(); 
}
@Override
public int getChangeMobNum(long accId, String cmob) {
	String q1 = "UPDATE Customer c SET c.customerMobNum=:pmob WHERE c.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("pmob", cmob);
	return  query.executeUpdate(); 
}
@Override
public int getChangePassWord(long accId, String cpw) {
	String q1 = "UPDATE UserTable u SET u.loginPassword=:plpw WHERE u.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("plpw", cpw);
	return  query.executeUpdate(); 
}
@Override
public List<Transactions> loadAllTransactions() {
	TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e",Transactions.class);
	
	return query.getResultList();
}


@Override
	public int login(int adminId,String password)
	{
		TypedQuery<Integer> query=entityManager.createQuery("SELECT a.adminId FROM Admin a where a.adminId=:padminId and a.password=:ppassword",Integer.class);
		query.setParameter("padminId", adminId);
		query.setParameter("ppassword", password);
		
		try {
			int adminId1=query.getSingleResult();
			int loggeduser=adminId1;
			return loggeduser;	
		} catch (NoResultException e) {
			int loggeduser=0;
			return loggeduser;	
			
	}
	}

	@Override
	public Customer add(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}
	@Override
	public List<Transactions> loadDateTransactions(String dateOfTransaction) {
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e where e.dateOfTransaction=:ddate",Transactions.class);
		query.setParameter("ddate",dateOfTransaction);
		return query.getResultList();
	}
	@Override
	public List<Transactions> loadMonthTransactions(String monthTransaction) {
	
		System.out.println(monthTransaction);
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e WHERE SUBSTRING(e.dateOfTransaction, 4, 9) = :mmonth",Transactions.class);
		query.setParameter("mmonth",monthTransaction);
		List<Transactions> list=query.getResultList();
		return list;
		
	}
	@Override
	public List<Transactions> loadYearTransactions(String yearTransaction) {
		System.out.println(yearTransaction);
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e WHERE SUBSTRING(e.dateOfTransaction, 8, 9) = :yyear",Transactions.class);
		query.setParameter("yyear",yearTransaction);
		List<Transactions> list=query.getResultList();
		System.out.println(list);
		return list;
	}
	

@Override
 
public int getservId(long accId) {
 
TypedQuery<Integer> query = entityManager.createQuery("select s.serviceId from ServiceTracker s where s.accountId=:pId", Integer.class);
 
query.setParameter("pId", accId);
 
int id= query.getSingleResult(); 
 
return id;

}
 
@Override
 
public String getServiceTracker(int serviceId) {
 
TypedQuery<String> query = entityManager.createQuery("select s.serviceStaus from ServiceTracker s where s.serviceId=:pId", String.class);
 
query.setParameter("pId", serviceId);
System.out.println(serviceId);
String status= query.getSingleResult(); 
 
return status ;

}

	@Override
	public int getCheckBook(long accId, String sd, String ss) {
	
		String q = "UPDATE ServiceTracker s SET s.serviceStaus=:pss WHERE s.accountId=:pId";
		 
		System.out.println("AccId:st"+accId);
		 
		System.out.println("sd:st"+sd);
		 
		System.out.println("ss:st"+ss);
		 
		Query query=entityManager.createQuery(q);
		 
		query.setParameter("pId", accId);
		
		 
		query.setParameter("pss","Active");
		 
		return query.executeUpdate(); 

	}

@Override
 
public List<Transactions> loadMiniStatement(long accId) {
 
TypedQuery<Transactions> query = entityManager.createQuery("SELECT h FROM Transactions h WHERE h.accountId=:paId ",Transactions.class);
 
query.setParameter("paId", accId);
 
return query.getResultList();

}

	
	
	
	
	
 

}
