package com.bank.dao;


import java.util.List;
import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;

public interface IBankRepository {
  

public UserTable check(UserTable user);

public AccountMaster getAccountBalance(long accId);

public int getChangeAddress(long accId, String cadd);

public int getChangeMobNum(long accId,String cmob);

public int getChangePassWord(long accId, String cpw);
public List<Transactions> loadAllTransactions();

public Customer add(Customer customer);

int login(int adminId, String password);




public List<Transactions> loadDateTransactions(String  dateOfTransaction);




public List<Transactions> loadMonthTransactions(String monthTransaction);




public List<Transactions> loadYearTransactions(String yearTransaction);




public int getservId(long accId);




public String getServiceTracker(int sid);




public int getCheckBook(long accId, String sd, String ss);




public List<Transactions> loadMiniStatement(long accId);
}
