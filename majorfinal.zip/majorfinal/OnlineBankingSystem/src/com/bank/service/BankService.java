package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dao.IBankRepository;
import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;

@Service
@Transactional
public class BankService implements IBankService {
	@Autowired
	private IBankRepository bankRepository;

	public UserTable check(UserTable user) {
		// TODO Auto-generated method stub
		return bankRepository.check(user); 
	}


	@Override
	public AccountMaster getAccountBalance(long accId) {
		// TODO Auto-generated method stub
		return bankRepository.getAccountBalance(accId);
	}


	@Override
	public int getChangeAddress(long accId, String cadd) {
		return bankRepository.getChangeAddress(accId, cadd);
	}


	@Override
	public int getChangeMobNum(long accId,String cmob) {
		return bankRepository.getChangeMobNum(accId, cmob);
	}


	@Override
	public int getChangePassWord(long accId, String cpw) {
		return bankRepository.getChangePassWord(accId, cpw);
	}


	@Override
	public List<Transactions> loadAllTransactions() {
		// TODO Auto-generated method stub
		return bankRepository.loadAllTransactions();
	}


	

	@Override
	public Customer add(Customer customer) {
		
		return bankRepository.add(customer);
	}


	@Override
	public int login(int adminId, String password) {
		
		return bankRepository.login( adminId,password);
	}


	@Override
	public List<Transactions> loadDateTransactions(String dateOfTransaction) {
		// TODO Auto-generated method stub
		return bankRepository.loadDateTransactions( dateOfTransaction);
	}


	@Override
	public List<Transactions> loadMonthTransactions(String monthTransaction) {
		
		return bankRepository.loadMonthTransactions( monthTransaction);
	}


	@Override
	public List<Transactions> loadYearTransactions(String yearTransaction) {
		
		return bankRepository.loadYearTransactions(yearTransaction);
	}
	
	

@Override
 
public List<Transactions> loadMiniStatement(long accId) {
 

 
return bankRepository.loadMiniStatement(accId);

}
 
@Override
 
public int getservId(long accId) {
 

 
return bankRepository.getservId(accId);

}

@Override
 
public String getServiceTracker(int sid) {
 

 
return bankRepository.getServiceTracker( sid);

}


@Override
public int getCheckBook(long accId, String sd, String ss) {
	
	return bankRepository.getCheckBook(accId,  sd,  ss) ;
}



	

	
		
		
	

}
